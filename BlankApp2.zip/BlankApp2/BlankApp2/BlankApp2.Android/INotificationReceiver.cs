using System.Threading.Tasks;

namespace BlankApp2.ViewModels
{
    interface INotificationReceiver
	{
		Task StartAsync ();

		void Stop ();
	}
}