﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace BlankApp2.ViewModels
{
    public interface IAudioService
    {
        Task startRecord();
        Task endRecord(string audio_name);
        Task startPlay(string audio_name);
        void endPlay();
    }
}
