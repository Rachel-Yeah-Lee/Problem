﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace BlankApp2.Views
{
	[XamlCompilation(XamlCompilationOptions.Compile)]
	public partial class tea : ContentPage
	{
		 public tea()
        {
            InitializeComponent();
        }
        int num = 0, num1=0, num2=0; string varString, varstring1,varstring2;

        private void ImageButton_Clicked_2(object sender, EventArgs e)
        {
            num2++;

            varstring2 = Convert.ToString(num2);
            hiii.Text = varstring2;

        }

        private void ImageButton_Clicked_1(object sender, EventArgs e)
        {
            num1++;

           varstring1 = Convert.ToString(num1);
            hii.Text = varstring1;

        }

        private void ImageButton_Clicked(object sender, EventArgs e)
        {
            
            num++;
           
         varString = Convert.ToString(num);
            hi.Text = varString;

        }
        void OnSliderValueChanged(object sender, ValueChangedEventArgs args)
        {
            hi.Text = varString;
            hii.Text = varstring1;
            hiii.Text = varstring2;
        }
	}
}