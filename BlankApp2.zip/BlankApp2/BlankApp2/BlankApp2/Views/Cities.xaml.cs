﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace BlankApp2.Views
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class Cities : ContentPage
    {
        public Cities()
        {
            InitializeComponent();
        }
        async void H3(object sender, EventArgs args)
        {

            await Navigation.PushAsync(new ClubList());
        }
    }
}